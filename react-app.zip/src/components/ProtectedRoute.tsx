import React from "react";
import { Navigate } from "react-router-dom";

/**
 * TODO 3 :: Add a better way to handle the central storage for authenticated user throughout the application
 */
const ProtectedRoute: React.FC<{ children: JSX.Element }> = ({ children }) => {
  const user = localStorage.getItem('user');
  return user ? children : <Navigate to="/signin" />;
};

export default ProtectedRoute;
