import { dummyApi } from "../utils/MockUtils";
import data from "./db.json";

export default function usersApi() {
  return {
    getUsers({ page, pageSize }) {
      /*
       TODO 2: mock the api for a 3 second delay, data is stored in db.json as users list
       we need to make sure the response of this method is correctly paginated
       */
      /**
       * expected structure:  {
          total_pages,
          page,
          page_size,
          data: List<User>,
        }
       */
      /* SOLUTION END */
    },
  };
}
